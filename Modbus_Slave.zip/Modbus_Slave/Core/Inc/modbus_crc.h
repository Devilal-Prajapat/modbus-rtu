/*
 * modbus_crc.h
 *
 *  Created on: 02-Jan-2023
 *      Author: devilalprajapat
 */

#ifndef INC_MODBUS_CRC_H_
#define INC_MODBUS_CRC_H_

unsigned short CRC16(unsigned char *puchMsg, unsigned short usDataLen);

#endif /* INC_MODBUS_CRC_H_ */
